<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends CI_Controller 
{
	function __construct()
  {
    parent::__construct();
    $this->load->model('Msetting');
  }
  public function index()
  {
    $data = array('title' => 'Setting',
                    //'datauser' => $this->model->getdatausers(),
                    'judulweb' => $this->Msetting->gettitle()
                 );
    $this->load->view('setting/index.php',$data);
  }
}