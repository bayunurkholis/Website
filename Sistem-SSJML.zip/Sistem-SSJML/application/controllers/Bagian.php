<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Bagian extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Mbagian','model');
        $this->load->model('Msetting'); 
        check_not_login();
    }
	public function index()
	{
		$data = array('title' => 'Data Bagian',
                  'databagian' => $this->model->getdatabagian(),
                  'judulweb' => $this->Msetting->gettitle()
                  );
	    $this->load->view('bagian/index.php',$data);
	}
	public function simpan()
	{
        $nama_bagian = $this->input->post('nama_bagian');
        $data  = array(
                            'nama_bagian' => $nama_bagian
                     );

            $this->model->insertbagian($data);
            $this->session->set_flashdata('notifikasi', '<div class="alert alert-success">
                                                              <h4>INFO </h4>
                                                           <p>Berhasil Simpan</p>
                                                         </div>'
                                        );
            redirect('bagian');
    }
    
    public function update()
    {
        $id_bagian= $this->input->post('id_bagian');
        $nama_bagian = $this->input->post('nama_bagian');
        $data  = array(
                            'nama_bagian' => $nama_bagian
                     );

        $this->model->updatebagian($data,$id_bagian);
        $this->session->set_flashdata('notifikasi', '<div class="alert alert-success">
                                                              <h4>INFO </h4>
                                                           <p>Berhasil Diperbarui</p>
                                                    </div>'
                                        );
        redirect('bagian');
    }
  
	public function delete($id_bagian)
	{
		$this->model->deletebagian($id_bagian);
		$this->session->set_flashdata('notifikasi', '<div class="alert alert-danger">
                                                                <h4>INFO </h4>
                                                              <p>Berhasil Dihapus</p>
                                                 </div>'
                                 );
        redirect('bagian');
	}
}
