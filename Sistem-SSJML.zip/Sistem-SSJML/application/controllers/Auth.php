<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function login()
	{
		check_already_login();
		$this->load->view('login');
	}
	public function logout()
	{
		$params = array('id_user');
		$this->session->unset_userdata($params);
		redirect('auth/login');
	}
	public function process()
	{
		$post = $this->input->post(null, TRUE);
		$this->load->model('Muser');
		$query = $this->Muser->login($post);
			if ($query)
			{
				$row = $query;
				$params = array(
					'id_user'=>$row->id_user);
				$this->session->set_userdata($params);
				echo "<script>
				       alert('Login berhasil');
				       window.location='".site_url('dashboard')."';
				       </script>";
			} 
			else 
			{
              echo "<script>
				       alert('Login gagal, Username / Password salah');
				       window.location='".site_url('auth/login')."';
				       </script>";
			}
	}
}