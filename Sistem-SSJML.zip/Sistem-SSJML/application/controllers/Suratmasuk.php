<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Suratmasuk extends CI_Controller {

  public function __construct()
  {
      parent::__construct();
      $this->load->model('Msuratmasuk','model');
      $this->load->model('Msetting'); 
      $this->load->library('pagination');
      check_not_login();
  }

	function index()
	{
      $searchby = $this->input->post('searchby');
      $keyword = $this->input->post('keyword');

      $config['base_url'] = site_url('Suratmasuk/index'); //site url
      $config['total_rows'] = $this->db->count_all('view_masuk'); //total row
      $config['per_page'] = 15;  //show record per halaman
      $config["uri_segment"] = 3;  // uri parameter
      $choice = $config["total_rows"] / $config["per_page"];
      $config["num_links"] = 5;
      $data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        // Membuat Style pagination untuk BootStrap v4
      $config['first_link']       = 'First';
      $config['last_link']        = 'Last';
      $config['next_link']        = 'Next';
      $config['prev_link']        = 'Prev';
      $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-center">';
      $config['full_tag_close']   = '</ul></nav></div>';
      $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
      $config['num_tag_close']    = '</span></li>';
      $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
      $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
      $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
      $config['next_tagl_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
      $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
      $config['prev_tagl_close']  = '</span>Next</li>';
      $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
      $config['first_tagl_close'] = '</span></li>';
      $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
      $config['last_tagl_close']  = '</span></li>';
        
      $this->pagination->initialize($config);
      if (empty($searchby)||empty($keyword))
          {
        		  $data = array('title' => 'Surat Masuk',
                         'judulweb' => $this->Msetting->gettitle(),
        			           'datasuratmasuk' => $this->model->getdatasuratmasuk($config["per_page"],$data["page"]),
                         'dataalldatasuratmasuk' => $this->model->getalldatasuratmasuk(),
                         'searchby' =>$searchby,
                         'keyword'=> $keyword,
                         'pagination' => $this->pagination->create_links()
        		             );
          }
      else
          {
              $data = array('title' => 'Surat Masuk',
                         'judulweb' => $this->Msetting->gettitle(),
                         'searchby' =>$searchby,
                         'keyword'=> $keyword,
                         'datasuratmasuk' => $this->model->getdatasuratmasuk($config["per_page"],$searchby,$keyword,$data["page"]),
                         'pagination' => $this->pagination->create_links()
                         );
          }   
    	$this->load->view('suratmasuk/index',$data);
	}
	  
  function delete($kd_transaksi)
  {
        $this->model->deleteitem($kd_transaksi);
        $this->model->delete($kd_transaksi);
        $this->session->set_flashdata('notifikasi', '<div class="alert alert-danger">
                                                                <h4>INFO </h4>
                                                              <p>Berhasil Dihapus</p>
                                                 </div>'
                                 );

        redirect('suratmasuk');
  }  
}
