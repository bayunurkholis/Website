<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

    public function __construct()
    {
      parent::__construct();
      $this->load->model('Muser','model');
      $this->load->model('Msetting'); 
      check_not_login();
    }
	public function index()
	{
		$data = array('title' => 'Data User',
                  'datauser' => $this->model->getdatausers(),
                  'judulweb' => $this->Msetting->gettitle()
                  );
	  $this->load->view('users/index.php',$data);
	}
	public function simpan()
	{
        $nama_user = $this->input->post('nama_user');
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $hak_user= $this->input->post('hak_user');

        if(empty($this->input->post('hak_user')))
          {
              echo "<script>alert('Hak User Belum Dipilih !! ');history.go(-1);</script>";
          }
        else
          {
            $data  = array(
                            'nama_user' => $nama_user,
                            'username' => $username,
                            'password' => password_hash($password, PASSWORD_BCRYPT),
                            'hak_user' => $hak_user                        
                      );

            $this->model->insertuser($data);
            $this->session->set_flashdata('notifikasi', '<div class="alert alert-success">
                                                              <h4>INFO </h4>
                                                           <p>Berhasil Simpan</p>
                                                         </div>'
                                        );
            redirect('users');
         }
  }
  public function update()
  {
    $id_user = $this->input->post('id_user');
    $nama_user = $this->input->post('nama_user');
    $username = $this->input->post('username');
    $password = $this->input->post('password');
    $hak_user= $this->input->post('hak_user');

    $data  = array(
                    'nama_user' => $nama_user,
                    'username' => $username,
                    'password' => password_hash($password, PASSWORD_BCRYPT),
                     'hak_user' => $hak_user                        
                  );

    $this->model->updateuser($data, $id_user);
    $this->session->set_flashdata('notifikasi', '<div class="alert alert-success">
                                                                <h4>INFO </h4>
                                                              <p>Berhasil Update</p>
                                                    </div>'
                                      );
    redirect('users');
  }
	public function delete($id_user)
	{
		$this->model->deleteuser($id_user);
		$this->session->set_flashdata('notifikasi', '<div class="alert alert-danger">
                                                                <h4>INFO </h4>
                                                              <p>Berhasil Dihapus</p>
                                                 </div>'
                                 );
    redirect('users');
	}
}
