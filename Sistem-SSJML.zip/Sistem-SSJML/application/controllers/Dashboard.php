<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller 
{
	function __construct()
    {
        parent::__construct();
        $this->load->model('Mdashboard');
		$this->load->model('Msetting'); 
        check_not_login();
    }
    function index()
	{
		$data = array('title' => 'Dashboard',
		              'judulweb' => $this->Msetting->gettitle()
		             );
		$this->load->view('templates/index',$data);
	}
}
