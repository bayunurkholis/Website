<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

    public function __construct()
    {
      parent::__construct();
      $this->load->model('Msetting'); 
      check_not_login();
    }
	public function index()
	{
      $data = array('title' => 'Profile',
                     //'datauser' => $this->model->getdatausers(),
                    'judulweb' => $this->Msetting->gettitle()
                   );
      $this->load->view('profile/index.php',$data);
	}
}