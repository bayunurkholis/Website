<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Muser extends CI_Model {
   
  function login($post)
   {
    $password = $post['password'];

   	$this->db->where('username', $post['username']);
    $query = $this->db->get('tb_user')->row();

    if (!$query) return false;

    $hash= $query->password;
   	if(!password_verify($password,$hash)) return false;
   
   	return $query;
   }
  function get($id = null)
   {
   	 $this->db->from('tb_user');
   	 if ($id != null)
   	 {
   	 	$this->db->where('id_user', $id);
   	 }
   	 $query = $this->db->get();
       return $query;
   }
  function getdatausers()
  {
    $this->db->select('*');
    $this->db->from('tb_user');
    $query = $this->db->get();
    return $query;
  }
  function edit($id)
   {
     $query = $this->db->get_where('tb_user',array('id_user' => $id ));
     return $query;
   }  
  function insertuser($data)
  {
     $this->db->insert('tb_user',$data);
  } 
  function deleteuser($id)
  {
    $this->db->where('id_user',$id);
    $this->db->delete('tb_user');
  }
  function updateuser($data,$id)
  {
    $this->db->where('id_user',$id);
    $this->db->update('tb_user', $data);
  }
}   
