<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Msuratkeluar extends CI_Model 
{
    function getdatasuratkeluar($jml, $start =0)
    {
      $this->db->select('*');
      $this->db->from('tb_surat_keluar');
      $this->db->join('tb_bagian','tb_bagian.id_bagian = tb_surat_keluar.id_bagian');
      $this->db->order_by('Id_srtklr','DESC');
      $this->db->limit($jml,$start);
      $query = $this->db->get();
      return $query;
    }
    function getdatasuratkeluarfilter($jml,$searchby, $keyword, $start =0 )
    {
      $this->db->select('*');
      $this->db->from('tb_surat_keluar');
      $this->db->join('tb_bagian','tb_bagian.id_bagian = tb_surat_keluar.id_bagian');
      $this->db->where($searchby, $keyword);
      $this->db->order_by('Id_srtklr','DESC');
      $this->db->limit($jml,$start);
      $query = $this->db->get();
      return $query;
    }
    function getalldatasuratkeluar()
    {
      $this->db->select('*');
      $this->db->from('view_keluar');
      $this->db->order_by('Id_srtklr','DESC');
      $query = $this->db->get();
      return $query;
    }

}