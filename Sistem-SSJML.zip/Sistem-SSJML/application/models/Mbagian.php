<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Mbagian extends CI_Model {

  function getdatabagian()
  {
    $this->db->select('*');
    $this->db->from('tb_bagian');
    $query = $this->db->get();
    return $query;
  } 
  function insertbagian($data)
  {
     $this->db->insert('tb_bagian',$data);
  } 
  function deletebagian($id)
  {
    $this->db->where('id_bagian',$id);
    $this->db->delete('tb_bagian');
  }
  function updatebagian($data,$id)
  {
    $this->db->where('id_bagian',$id);
    $this->db->update('tb_bagian', $data);
  }
}   
