<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Msetting extends CI_model
{
 function gettitle()
    {
      $this->db->select('*');
      $this->db->from('tb_setting');
      $this->db->where('id_set','1');
      $query = $this->db->get();
      return $query;
    }
 function updatetitle($data,$id)
    {
      $this->db->where('id_set',$id);
      $this->db->update('tb_setting', $data);
    }   
}    