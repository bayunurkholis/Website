<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Msuratmasuk extends CI_Model 
{
    function getdatasuratmasuk($jml, $start =0)
    {
      $this->db->select('*');
      $this->db->from('tb_surat_masuk');
      $this->db->join('tb_bagian','tb_bagian.id_bagian = tb_surat_masuk.id_bagian');
      $this->db->order_by('id_srtmsk','DESC');
      $this->db->limit($jml,$start);
      $query = $this->db->get();
      return $query;
    }
    function getdatasuratmasukfilter($jml,$searchby, $keyword, $start =0 )
    {
      $this->db->select('*');
      $this->db->from('tb_surat_masuk');
      $this->db->join('tb_bagian','tb_bagian.id_bagian = tb_surat_masuk.id_bagian');
      $this->db->where($searchby, $keyword);
      $this->db->order_by('id_srtmsk','DESC');
      $this->db->limit($jml,$start);
      $query = $this->db->get();
      return $query;
    }
    function getalldatasuratmasuk()
    {
      $this->db->select('*');
      $this->db->from('view_masuk');
      $this->db->order_by('id_srtmsk','DESC');
      $query = $this->db->get();
      return $query;
    }
}