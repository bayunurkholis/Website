
<?php $this->load->view('templates/header')?>
<style type="text/css">

   #notifications {
    cursor: pointer;
    position: fixed;
    right: 0px;
    z-index: 9999;
    bottom: 0px;
    margin-bottom: 22px;
    margin-right: 15px;
    min-width: 300px; 
    max-width: 800px; }
</style>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <!-- Logo -->
<header class="main-header">
      <!-- mini logo for sidebar mini 50x50 pixels -->
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-">
      <!-- Sidebar toggle button-->
    <ul>
 
    <h3 href="#" class="sidebar-toggle" data-toggle="push-menu" role="button"> <?php foreach ($judulweb->result() as $baris) { echo "$baris->nama_pt"; } ?>
    <span class="sr-only">Toggle navigation</span>
    </h3>
    </ul>
    </nav>
    <div id="notifications"><?php echo $this->session->flashdata('notifikasi'); ?></div> 
  </header>

<?php $this->load->view('templates/sidebar')?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
     <section class="content-header">
      <h1>
        PROFILE SAYA
      </h1>
    </section>

<!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <br>
            <div class="text-center">
                   <img src="<?php echo base_url()?>template/dist/img/default.png" class="profile-user-img img-fluid img-circle" alt="User Image">
            </div>
                       
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form">
              <div class="box-body">
                <div class="text-center">
                 <label for="exampleInputEmail1"><?=$this->fungsi->user_login()->nama_user?></label>
               </div>
               <div class="text-center">
               <table class="table table-sm mt-4">
                            <tr>
                                <td>Username </td>
                                <td class="text-dark"><b><?=$this->fungsi->user_login()->username?></b></td>
                            </tr>
              </table>
            </div>
            </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <div class="text-center">
                 <a 
                      href="javascript:;"
                      data-id="<?=$this->fungsi->user_login()->id_user ?>"
                      data-nama_user="<?=$this->fungsi->user_login()->nama_user ?>"
                      data-username="<?=$this->fungsi->user_login()->username ?>"
                      data-toggle="modal" data-target="#edit-data"
                      class="btn btn-primary"> Edit Profile 
                </a>
              </div>
              </div>

            </form>
          </div>
        </div>
          <!-- /.box -->
        </div>
      </div>
    </section>


<?php $this->load->view('templates/footer') ?>

<div class="modal fade" id="edit-data">
       <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">EDIT PROFILE</h4>
            </div>
               <form role="form" action="<?php echo site_url('profile/update')?>" enctype="multipart/form-data" method="post">
                  
                     <input type="hidden" name="_token" value="">
                        <br>
                      <div class="box-body">
                         
                            <input type="hidden" class="form-control" id="id_user" name="id_user" readonly ="readonly" >

                          <div class="text-center">    
                            <img src="<?php echo base_url()?>template/dist/img/default.png" class="profile-user-img img-fluid img-circle" alt="User Image">   
                          </div>

                            <div class="form-group row">
                               <div class="col-md-10 col-md-offset-1">
                                <label for="name">Nama Lengkap</label>
                                <input name="id" type="hidden" >
                                <input type="text" class="form-control" id="nama_user" name="nama_user"
                                placeholder="Enter Nama Lengkap" required>
                              </div>
                            </div>

                           <div class="form-group row">
                               <div class="col-md-10 col-md-offset-1">
                                <label for="cust_alamat">Username</label>
                                <input name="id" type="hidden" >
                                <input type="text" class="form-control" id="username" name="username"
                                 placeholder="Enter Username" ></input>
                               </div>
                           </div>

                           <div class="form-group row">
                              <div class="col-md-10 col-md-offset-1">
                                <label for="cust_alamat">Password</label>
                                <input name="id" type="hidden" >
                                <input type="password" class="form-control"  name="password"
                                placeholder="Enter New Password" required></textarea>
                              </div>
                           </div>
                       
                          <div class="box-footer">
                             <div class="col-md-10 col-md-offset-1">
                               <button type="submit" class="btn btn-primary">Update</button>
                               <a href="<?=site_url('profile/index')?>" class="btn btn-default" style = "float: right">Cancel</a>
                              </div>
                        </div>    
                       </div>   
                          <!-- Card body -->
              
                    </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>

    <script>
    $(document).ready(function() {
        // Untuk sunting
        $('#edit-data').on('show.bs.modal', function (event) {
            var div = $(event.relatedTarget) // Tombol dimana modal di tampilkan
            var modal = $(this)

            // Isi nilai pada field
            modal.find('#id_user').attr("value",div.data('id'));
            modal.find('#nama_user').attr("value",div.data('nama_user'));
            modal.find('#username').attr("value",div.data('username'));
        });
    });
</script>
<script> 
    $('#notifications').slideDown('slow').delay(3000).slideUp('fast');  
</script>