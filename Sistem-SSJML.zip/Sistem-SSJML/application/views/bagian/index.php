<style type="text/css">
    .panel-body{
        overflow: auto;
      }

   #notifications {
    cursor: pointer;
    position: fixed;
    right: 0px;
    z-index: 9999;
    bottom: 0px;
    margin-bottom: 22px;
    margin-right: 15px;
    min-width: 300px; 
    max-width: 800px; 

    }
</style>
<?php $this->load->view('templates/header')?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <!-- Logo -->
    
   <header class="main-header">
      <!-- mini logo for sidebar mini 50x50 pixels -->
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-">
      <!-- Sidebar toggle button-->
      <ul>
 
     <h3 href="#" class="sidebar-toggle" data-toggle="push-menu" role="button"> <?php foreach ($judulweb->result() as $baris) { echo "$baris->nama_pt"; } ?>
        <span class="sr-only">Toggle navigation</span>
      </h3>
     </ul>
    </nav>
    
    <div id="notifications"><?php echo $this->session->flashdata('notifikasi'); ?></div> 
  </header>
<?php $this->load->view('templates/sidebar')?>

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       BAGIAN
      </h1>
    </section>
    <br>
  <div class="container" bgcolor= "#fff">
    <div class="row">
        <div class="col-md-15">
            <div class="panel">
                <div class="panel-heading">
                  <a href="#" class="btn btn-primary " data-toggle="modal" data-target="#tambah-bagian">Tambah Bagian</a>
                    <!-- /.card-header -->
                      <div class="panel-body">
                       <table id="listdatabagian" class="table table-striped">
                            <thead>
                            <tr>
                                <th style="width: 10px">No</th>
                                <th>Nama Bagian</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                             <?php $no = 0;
                              foreach ($databagian->result_array() as $rows){?>
                              <tr>
                                <td><?= ++$no; ?></td>
                                <td><?= $rows['nama_bagian']?></td>
                                <td>
                                  <a class="btn btn-danger text-danger" onclick="return confirm('Are You Sure You Want To Delete ?')" href="  <?=site_url()?>Bagian/delete/<?= $rows['id_bagian']; ?>">
                                    <span class="fa fa-trash"></span>
                                  </a>
                                  <a class="btn" data-toggle="modal" data-target="#edit-bagian<?= $rows['id_bagian']?>">
                                      <span class="fa fa-edit"></span>
                                  </a>
                                </td>
                              </tr>
                              <?php } ?>
                            </tbody>
                        </table>
                     </div>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>
      </div>
    </div>
        <!-- /.row -->
  </div>

<?php $this->load->view('templates/footer') ?>


<div class="modal fade" id="tambah-bagian">
       <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">TAMBAH BAGIAN</h4>
            </div>
            <form role="form" action="<?php echo site_url('Bagian/simpan')?>" enctype="multipart/form-data" method="post">

            <div class="panel-body">
                        <div class="form-group row">
                               <div class="col-md-10 col-md-offset-1">
                                <label for="NAMA BARANG">NAMA BAGIAN : </label>
                                <input type="text" style="text-transform: uppercase;" class="form-control" name="nama_bagian" required>
                               </div>
                        </div>    
                           
                        <div class="box-footer">
                             <div class="col-md-10 col-md-offset-1">
                               <button type="submit" class="btn btn-primary">SIMPAN</button>
                               <button type="button" class="btn btn-default" data-dismiss="modal" style = "float: right">
                                  Cancel
                               </button>
                              </div>
                        </div> 
                </div>
           </form> 
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>

 <?php foreach ($databagian->result_array() as $rows)              
            { 
              $rows['id_bagian'];
              $rows['nama_bagian'];
 ?> 
 <script>
  $(function () {
    $('#listdatabagian').DataTable()
  })
</script>                   
 <div class="modal fade" id="edit-bagian<?= $rows['id_bagian']?>">
       <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">EDIT DATA</h4>
            </div>
               <form role="form" action="<?php echo site_url('Bagian/update')?>" enctype="multipart/form-data" method="post">

                  <div class="panel-body">
                          <input type="hidden" class="form-control" value="<?= $rows['id_bagian'] ?>" name="id_bagian" readonly="readonly">
                           <div class="form-group row">
                               <div class="col-md-10 col-md-offset-1">
                                <label>NAMA BAGIAN : </label>
                                <input type="text" style="text-transform: uppercase"  class="form-control" value="<?= $rows['nama_bagian'] ?>" name="nama_bagian" >
                               </div>
                          </div> 
                            
                          <div class="box-footer">
                             <div class="col-md-10 col-md-offset-1">
                               <button type="submit" class="btn btn-primary">Update</button>
                               <button type="button" class="btn btn-default" data-dismiss="modal" style = "float: right">
                                  Cancel
                               </button>
                              </div>
                        </div> 
                </div>
           </form> 
        </div>
        <!-- /.modal-content -->
    </div>

    <!-- /.modal-dialog -->
  </div>

  <?php } ?>
 
<script> 
    $('#notifications').slideDown('slow').delay(2000).slideUp('fast');  
</script>

