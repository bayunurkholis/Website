
<?php $this->load->view('templates/header')?>
<style type="text/css">
    .panel-body{
        overflow: auto;
      }
</style> 
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <!-- Logo -->
  
   <header class="main-header">
      <!-- mini logo for sidebar mini 50x50 pixels -->
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar">
      <!-- Sidebar toggle button-->
      <ul>
       <h3 href="#" class="sidebar-toggle" data-toggle="push-menu" role="button"> <?php foreach ($judulweb->result() as $baris) { echo "$baris->nama_pt"; } ?> 
        <span class="sr-only">Toggle navigation</span>
      </h3>
      <!--
       <a href="#" data-toggle="control-sidebar" style="float: right;"><i class="fa fa-gears"></i></a>-->
     </ul>
    </nav>
  </header>

 <?php $this->load->view('templates/sidebar')?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        DASHBOARD
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
       
  
      
        <!-- ./col -->
      </div>  

        <div class="row">
        <div class="col-md-6">
       <!-- BAR CHART -->
          <div class="box box-info">
            <div class="box-header with-border">
               <i class="fa fa-bar-chart-o"></i>
              <h3 class="box-title">Bar Chart Surat Masuk Bulan Ini</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body chart-responsive">
              <div class="chart" id="bar-bulanini" style="height: 300px;"></div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->   
          </div>
           <div class="col-md-6">
             <!-- BAR CHART -->
              <div class="box box-danger">
                <div class="box-header with-border">

                   <i class="fa fa-bar-chart-o"></i>
                  <h3 class="box-title">Bar Chart Surat Keluar Bulan Ini</h3>

                  <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div>
                <div class="box-body chart-responsive">
                  <div class="chart" id="bar-bulanlalu" style="height: 300px;"></div>
                </div>
                <!-- /.box-body -->
              </div>
              <!-- /.box -->   
           </div>
      </div>
      <center>
          <div class="box box-primary" style="float: center; width: 75%">
            <div class="box-header with-border">
              <i class="fa fa-bar-chart-o"></i>
              <h3 class="box-title">KETERANGAN</h3>
            </div>
            <div class="panel-body">
             
             
                <table>
                  <thead>
                    <tr>
                     <th><div style="border:0; width: 30px; height: 30px; background-color:#B0E0E6 "></div></th>
                     <th style="padding: 20px; padding-right: 200px;">SURAT MASUK </th>

                     <th><div style="border:0; width: 30px; height: 30px; background-color:#FFD700 "></div></th>
                     <th style="padding: 20px;">SURAT KELUAR  </th>
                   </tr>
                 </thead>
                 <thead>
                    <tr>
                     <th><div style="border:0; width: 30px; height: 30px; background-color:#A0522D "></div></th>
                     <th style="padding: 20px;">PAUSE</th>
                     <th><div style="border:0; width: 30px; height: 30px; background-color:#00FF7F"></div></th>
                     <th style="padding: 20px;">SELESAI</th>
                   </tr>
                 </thead>
                </table>  
     
            <!-- /.box-body-->
          </div>
          <!-- /.box -->
        </div>
        </center>
      <!-- /.row 
      <center>
           <form action="<?=site_url('Laporanperbandingan/export_excel')?>" method="post">                   
              <button class="btn btn-success" type="submit" id="button-addon3"><span class="fa fa-file-excel-o"></span> Convert Excel</button></th>
            </form> 
      </center>
    </section>
    -->
    <!-- /.content -->
     </section>      
  </div>


    <!-- /.content-wrapper -->
  <?php $this->load->view('templates/footer') ?> 

<script type="text/javascript">
 function parseSVG(s) {
        var div= document.createElementNS('http://www.w3.org/1999/xhtml', 'div');
        div.innerHTML= '<svg xmlns="http://www.w3.org/2000/svg">'+s+'</svg>';
        var frag= document.createDocumentFragment();
        while (div.firstChild.firstChild)
            frag.appendChild(div.firstChild.firstChild);
        return frag;
    };

  var theData = [
                  {kategori:"SL",value:<?= round($jmltransspl->totalqty,3); ?>},
                  {kategori:"E",value:<?= round($jmltranselektrik->totalqty1,3); ?>},
                  {kategori:"TI",value:<?= round($jmltransti->totalqty2,3); ?>},
                  {kategori:"BM",value:<?= round($jmltransbm->totalqty3,3); ?>},
                  {kategori:"TE",value:<?= round($jmltranste->totalqty4,3); ?>},
                  {kategori:"SB",value:<?= round($jmltranssb->totalqty5,3); ?>},
                  {kategori:"W",value:<?= round($jmltranswelding->totalqty6,3); ?>},
                  {kategori:"FG",value:<?= round($jmltransfg->totalqty7,3);?>},
                  {kategori:"P",value:<?= round($jmltranspf->totalqty8,3); ?>},
                  {kategori:"U",value:<?= round($jmltransut->totalqty9,3); ?>}
                 ];            

Morris.Bar ({
element: 'bar-bulanini',
data: theData,
  xkey: 'kategori',
  ykeys: ['value'],
  labels: ['Jumlah'],
  barRatio: 0.4,
  xLabelAngle: 35,
  hideHover: 'auto',
  barColors: function (row, series, type) {
    console.log("--> "+row.label, series, type);
    if(row.label == "SL") return "#B0E0E6";
    else if(row.label == "E") return "#A0522D";
    else if(row.label == "TI") return "#708090";
    else if(row.label == "BM") return "#FFFF00";
    else if(row.label == "TE") return "#00FF7F";
    else if(row.label == "SB") return "#FFF5EE";
    else if(row.label == "W") return "#FFD700";
    else if(row.label == "FG") return "#0000FF";
    else if(row.label == "P") return "#00FFFF";
    else if(row.label == "U") return "#f39c12";
  }
});

var items = $("#bar-bulanini").find( "svg" ).find("rect");
$.each(items,function(index,v){
    var value = theData[index].value;
    var newY = parseFloat( $(this).attr('y') - 20 );
    var halfWidth = parseFloat( $(this).attr('width') / 2 );
    var newX = parseFloat( $(this).attr('x') ) +  halfWidth;
    var output = '<text style="text-anchor: middle; font: 12px sans-serif;" x="'+newX+'" y="'+newY+'" text-anchor="middle" font="10px &quot;Arial&quot;" stroke="none" fill="#000000" font-size="12px" font-family="sans-serif" font-weight="normal" transform="matrix(1,0,0,1,0,6.875)"><tspan dy="3.75">'+value+'</tspan></text>';
    $("#bar-bulanini").find( "svg" ).append(parseSVG(output));
});
</script>


<script type="text/javascript">

 
 function parseSVG(s) {
        var div= document.createElementNS('http://www.w3.org/1999/xhtml', 'div');
        div.innerHTML= '<svg xmlns="http://www.w3.org/2000/svg">'+s+'</svg>';
        var frag= document.createDocumentFragment();
        while (div.firstChild.firstChild)
            frag.appendChild(div.firstChild.firstChild);
        return frag;
    };

var theData = [
                  {kategori:"SL",value:<?= round($jmltransspl1->totalqty,3); ?>},
                  {kategori:"E",value:<?= round($jmltranselektrik1->totalqty1,3); ?>},
                  {kategori:"TI",value:<?= round($jmltransti1->totalqty2,3); ?>},
                  {kategori:"BM",value:<?= round($jmltransbm1->totalqty3,3); ?>},
                  {kategori:"TE",value:<?= round($jmltranste1->totalqty4,3); ?>},
                  {kategori:"SB",value:<?= round($jmltranssb1->totalqty5,3); ?>},
                  {kategori:"W",value:<?= round($jmltranswelding1->totalqty6,3);?>},
                  {kategori:"FG",value:<?= round($jmltransfg1->totalqty7,3);?>},
                  {kategori:"P",value:<?= round($jmltranspf1->totalqty8,3); ?>},
                  {kategori:"U",value:<?= round($jmltransut1->totalqty9,3); ?>}
                 ];

Morris.Bar ({
element: 'bar-bulanlalu',
data: theData,
  xkey: 'kategori',
  ykeys: ['value'],
  labels: ['Jumlah'],
  barRatio: 0.4,
  xLabelAngle: 35,
  hideHover: 'auto',
  barColors: function (row, series, type) {
    console.log("--> "+row.label, series, type);
    if(row.label == "SL") return "#B0E0E6";
    else if(row.label == "E") return "#A0522D";
    else if(row.label == "TI") return "#708090";
    else if(row.label == "BM") return "#FFFF00";
    else if(row.label == "TE") return "#00FF7F";
    else if(row.label == "SB") return "#FFF5EE";
    else if(row.label == "W") return "#FFD700";
    else if(row.label == "FG") return "#0000FF";
    else if(row.label == "P") return "#00FFFF";
    else if(row.label == "U") return "#f39c12";
  }
});

var items = $("#bar-bulanlalu").find( "svg" ).find("rect");
$.each(items,function(index,v){
    var value = theData[index].value;
    var newY = parseFloat( $(this).attr('y') - 20 );
    var halfWidth = parseFloat( $(this).attr('width') / 2 );
    var newX = parseFloat( $(this).attr('x') ) +  halfWidth;
    var output = '<text style="text-anchor: middle; font: 12px sans-serif;" x="'+newX+'" y="'+newY+'" text-anchor="middle" font="10px &quot;Arial&quot;" stroke="none" fill="#000000" font-size="12px" font-family="sans-serif" font-weight="normal" transform="matrix(1,0,0,1,0,6.875)"><tspan dy="3.75">'+value+'</tspan></text>';
    $("#bar-bulanlalu").find( "svg" ).append(parseSVG(output));
});

</script>
