
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
     <a href="#" class="logo">
      <center>
   <span class="logo-lg"><h4><b> SJML </b> Sistem </h4></span>
   </center>
   </a>
      <!-- Sidebar user panel -->
      <hr>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
          <li>
          <a href="<?=site_url('dashboard/index')?>">
          <i class="fa fa-dashboard"></i><span>DASHBOARD</span>
          </a>
       </li>
        <br>
        <a>
         <li class="header"><h5>NAVIGATION</h5></li>
        </a>
        <li class="treeview">
           <a href="#">
            <i class="fa fas fa-copy"></i>
            <span>MASTER</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=site_url('Users/index')?>"><i class="fa "></i> User </a></li>
            <li><a href="<?=site_url('Bagian/index')?>"><i class="fa "></i> Bagian </a></li>
          </ul>
        </li>
         
        <li class="treeview">
          <a href="#">
            <i class="fa fa-exchange"></i>
            <span>TRANSAKSI </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=site_url('suratmasuk/index')?>"><i class="fa "></i> Surat Masuk</a></li>
            <li><a href="<?=site_url('Suratkeluar/index')?>"><i class="fa "></i> Surat Keluar</a></li>
          </ul>
        </li>   

        <li class="treeview">
          <a href="#">
            <i class="fa fa-file"></i> <span>LAPORAN</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu"> 
            <li><a href="<?=site_url('Laporansuratmasuk/index')?>"><i class="fa "></i>Surat Masuk</a></li>
            <li><a href="<?=site_url('Laporansuratkeluar/index')?>"><i class="fa "></i>Surat Keluar</a></li>
          </ul>
        </li>
         <a>
         <li class="header"><h5>USER MENU</h5></li>
        </a>
         <li>
          <a href="<?=site_url('setting/index')?>" data-toggle="tab-content">
              <i class="fa fa-gear"></i> 
              <span>SETTING</span>
          </a>
        </li>
        <li>
          <a href="<?=site_url('Profile/index')?>">
            <i class="fa fa-user"></i> 
            <span>PROFILE</span>
          </a>
        </li>
        <li>
          <a href="#" data-toggle="modal" data-target="#modal-logout">
             <i class="fa fa-sign-out"></i>
             <span>LOGOUT</span>
          </a>
       </li>

    </section>
    <!-- /.sidebar -->
  </aside>
   <div class="modal fade" id="modal-logout">
       <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">LOGOUT</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Apakah anda yakin akan keluar&hellip;?</p>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a href="<?=site_url('auth/logout')?>" class="btn btn-primary">Logout</a>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>