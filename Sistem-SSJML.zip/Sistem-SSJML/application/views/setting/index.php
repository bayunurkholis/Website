
<?php $this->load->view('templates/header')?>
<style type="text/css">

   #notifications {
    cursor: pointer;
    position: fixed;
    right: 0px;
    z-index: 9999;
    bottom: 0px;
    margin-bottom: 22px;
    margin-right: 15px;
    min-width: 300px; 
    max-width: 800px; }
</style>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <!-- Logo -->
<header class="main-header">
      <!-- mini logo for sidebar mini 50x50 pixels -->
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-">
      <!-- Sidebar toggle button-->
    <ul>
 
    <h3 href="#" class="sidebar-toggle" data-toggle="push-menu" role="button"> <?php foreach ($judulweb->result() as $baris) { echo "$baris->nama_pt"; } ?>
    <span class="sr-only">Toggle navigation</span>
    </h3>
    </ul>
    </nav>
    <div id="notifications"><?php echo $this->session->flashdata('notifikasi'); ?></div> 
  </header>

<?php $this->load->view('templates/sidebar')?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
     <section class="content-header">
      <h1>
        SETTING TITLE WEBSITE
      </h1>
    </section>

<!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <br>

            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo site_url('Setting/update')?>" enctype="multipart/form-data" method="post">
              <div class="box-body">
                <div class="text-center">
                 <?php foreach ($judulweb->result() as $baris) {?>
                  <input type="hidden" class="form-control" name="id_set" value="<?php echo $baris->id_set; ?>">    
                       <div class="form-group row">
                          <div class="col-md-10 col-md-offset-1">
                                <label for="name">GANTI NAMA PT : </label>
                                <textarea type="text" class="form-control"  name="nama_pt"
                                ><?php echo $baris->nama_pt; ?></textarea>     
                          </div>
                       </div>
                       <div class="form-group row">
                          <div class="col-md-10 col-md-offset-1">
                                <label for="name">ALAMAT : </label>
                                <textarea type="text" class="form-control"  name="alamat"
                                ><?php echo $baris->alamat; ?></textarea>     
                          </div>
                       </div>
                       <div class="form-group row">
                          <div class="col-md-10 col-md-offset-1">
                                <label for="name">No Tlp : </label>
                                <input type="text" class="form-control" id="no_tlp" name="no_tlp" value="<?php echo $baris->no_tlp; ?>">
                               
                          </div>
                       </div>
                       <div class="form-group row">
                               <div class="col-md-10 col-md-offset-1">
                                <label for="url_img">Logo PT</label>
                                <input type="file" class="form-control" name="img_gallery" >
                                 <p >Foto Tipe : <i style="color: red" >gif/jpg/png</i> dan Max <i style="color: red">Lebar 4600</i>, 
                                                 <i style="color: red">Tinggi 2600</i>, 
                                                 <i style="color: red">Size 3.5 Mb</i>
                                 </p> 
                               </div>
                            </div>

                   <?php } ?>  
               </div>
            </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <div class="text-center">
                    <div class="col-md-10 col-md-offset-1">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </div>
              </div>

            </form>
          </div>
        </div>
          <!-- /.box -->
        </div>
      </div>
    </section>


<?php $this->load->view('templates/footer') ?>

<script> 
    $('#notifications').slideDown('slow').delay(3000).slideUp('fast');  
</script>