<style type="text/css">
    .panel-body{
        overflow: auto;
      }

   #notifications {
    cursor: pointer;
    position: fixed;
    right: 0px;
    z-index: 9999;
    bottom: 0px;
    margin-bottom: 22px;
    margin-right: 15px;
    min-width: 300px; 
    max-width: 800px; 

    }
</style>
<?php $this->load->view('templates/header')?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <!-- Logo -->
    
   <header class="main-header">
      <!-- mini logo for sidebar mini 50x50 pixels -->
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-">
      <!-- Sidebar toggle button-->
      <ul>
 
     <h3 href="#" class="sidebar-toggle" data-toggle="push-menu" role="button"> <?php foreach ($judulweb->result() as $baris) { echo "$baris->nama_pt"; } ?>
        <span class="sr-only">Toggle navigation</span>
      </h3>
     </ul>
    </nav>
    
    <div id="notifications"><?php echo $this->session->flashdata('notifikasi'); ?></div> 
  </header>
<?php $this->load->view('templates/sidebar')?>

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       USER
      </h1>
    </section>
    <br>
  <div class="container" bgcolor= "#fff">
    <div class="row">
        <div class="col-md-15">
            <div class="panel">
                <div class="panel-heading">
                  <a href="#" class="btn btn-primary " data-toggle="modal" data-target="#tambah-user">Tambah User</a>
                    <!-- /.card-header -->
                      <div class="panel-body">
                       <table id="listdatauser" class="table table-striped">
                            <thead>
                            <tr>
                                <th style="width: 10px">No</th>
                                <th>Nama User</th>
                                <th>Username</th>
                                <th>Hak User</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                             <?php $no = 0;
                              foreach ($datauser->result_array() as $rows){?>
                              <tr>
                                <td><?= ++$no; ?></td>
                                <td><?= $rows['nama_user']?></td>
                                <td><?= $rows['username']?></td>
                                <td><?= $rows['hak_user']?></td>
                                <td>
                                  <a class="btn btn-danger text-danger" onclick="return confirm('Are You Sure You Want To Delete ?')" href="  <?=site_url()?>Users/delete/<?= $rows['id_user']; ?>">
                                    <span class="fa fa-trash"></span>
                                  </a>
                                  <a class="btn" data-toggle="modal" data-target="#edit-user<?= $rows['id_user']?>">
                                      <span class="fa fa-edit"></span>
                                  </a>
                                </td>
                              </tr>
                              <?php } ?>
                            </tbody>
                        </table>
                     </div>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>
      </div>
    </div>
        <!-- /.row -->
  </div>

<?php $this->load->view('templates/footer') ?>


<div class="modal fade" id="tambah-user">
       <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">TAMBAH USER</h4>
            </div>
            <form role="form" action="<?php echo site_url('Users/simpan')?>" enctype="multipart/form-data" method="post">

            <div class="panel-body">

                         <div class="form-group row">
                               <div class="col-md-10 col-md-offset-1">
                                <label for="NAMA BARANG">NAMA USER : </label>
                                <input type="text" style="text-transform: uppercase;" class="form-control" name="nama_user" required>
                               </div>
                          </div> 
                        
                          <div class="form-group row">
                               <div class="col-md-10 col-md-offset-1">
                                <label for="NAMA BARANG">USERNAME : </label>
                                <input type="text"  class="form-control" name="username" required>
                               </div>
                          </div>

                          <div class="form-group row">
                               <div class="col-md-10 col-md-offset-1">
                                <label for="NAMA BARANG">PASSWORD : </label>
                                <input type="text" class="form-control" name="password" required>
                               </div>
                          </div>
                        
                          <div class="form-group row">
                              <div class="col-md-10 col-md-offset-1">
                                      <label for="harga" >HAK USER : </label>
                                            <select class="form-control"  name="hak_user" required>
                                                <option value="0" selected disabled>PILIH HAK USER</option>
                                                    <option value="Admin">Admin</option>
                                                    <option value="Other">Other</option>
                                            </select>
                             </div>
                           </div>
                          
                          <div class="box-footer">
                             <div class="col-md-10 col-md-offset-1">
                               <button type="submit" class="btn btn-primary">SIMPAN</button>
                               <button type="button" class="btn btn-default" data-dismiss="modal" style = "float: right">
                                  Cancel
                               </button>
                              </div>
                        </div> 
                </div>
           </form> 
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>

 <?php foreach ($datauser->result_array() as $rows)              
            { 
              $rows['id_user'];
              $rows['nama_user'];
              $rows['username'];
              $rows['password'];
 ?> 
 <script>
  $(function () {
    $('#listdatauser').DataTable()
  })
</script>                   
 <div class="modal fade" id="edit-user<?= $rows['id_user']?>">
       <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">EDIT DATA</h4>
            </div>
               <form role="form" action="<?php echo site_url('Users/update')?>" enctype="multipart/form-data" method="post">

                  <div class="panel-body">
                          <input type="hidden" class="form-control" value="<?= $rows['id_user'] ?>" name="id_user" readonly="readonly">
                           <div class="form-group row">
                               <div class="col-md-10 col-md-offset-1">
                                <label>NAMA USER : </label>
                                <input type="text" style="text-transform: uppercase"  class="form-control" value="<?= $rows['nama_user'] ?>" name="nama_user" >
                               </div>
                          </div> 
                         <div class="form-group row">
                           <div class="col-md-10 col-md-offset-1">
                            <label >USERNAME : </label>
                             <input type="text" class="form-control" name="username" value="<?= $rows['username']; ?>" >
                            </div>
                           </div> 

                          <div class="form-group row">
                               <div class="col-md-10 col-md-offset-1">
                                <label >PASSWORD : </label>
                                <input type="text" class="form-control" name="password" >
                               </div>
                          </div> 

                          <div class="form-group row">
                              <div class="col-md-10 col-md-offset-1">
                                  <label>HAK USER : </label>
                                    <select class="form-control"  name="hak_user" required>
                                    <option value="0" selected disabled> PILIH HAK USER</option>
                                      <?php if ($rows['hak_user'] == 'Admin') 
                                              echo "<option value='Admin' selected>
                                                      Admin</option> 
                                                    <option value='Other'>Other</option>";
                                       ?>
                                      <?php if( $rows['hak_user'] == 'Other') 
                                             echo "<option value='Other' selected>Other</option> 
                                                   <option value='Admin'>Admin</option>";
                                      ?>            
                                  </select>
                             </div>
                           </div>
                            
                          <div class="box-footer">
                             <div class="col-md-10 col-md-offset-1">
                               <button type="submit" class="btn btn-primary">Update</button>
                               <button type="button" class="btn btn-default" data-dismiss="modal" style = "float: right">
                                  Cancel
                               </button>
                              </div>
                        </div> 
                </div>
           </form> 
        </div>
        <!-- /.modal-content -->
    </div>

    <!-- /.modal-dialog -->
  </div>

  <?php } ?>
 
<script> 
    $('#notifications').slideDown('slow').delay(2000).slideUp('fast');  
</script>

