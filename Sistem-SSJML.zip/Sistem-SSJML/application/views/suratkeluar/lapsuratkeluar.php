<style type="text/css">
    .panel-body{
        overflow: auto;
    }
</style>
<?php $this->load->view('templates/header')?>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <!-- Logo -->
<header class="main-header">
      <!-- mini logo for sidebar mini 50x50 pixels -->
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-">
      <!-- Sidebar toggle button-->
       <ul>
        
         <h3 href="#" class="sidebar-toggle" data-toggle="push-menu" role="button"> <?php foreach ($judulweb->result() as $baris) { echo "$baris->nama_pt"; } ?>
           <span class="sr-only">Toggle navigation</span>
        </h3>
       </ul>
    </nav>
  </header>

     
<?php $this->load->view('templates/sidebar')?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       LAPORAN SURAT KELUAR
      </h1>
    </section>
    <br>
  <div class="container" bgcolor= "#fff">
    <div class="row">
        <div class="col-md-15">
            <div class="panel">
               <br>
                          <div class="form-group row">
                          <div class="col-md-10 col-md-offset-1">
                             <form action="<?=site_url('Laporansuratkeluar/index')?>" method="post">
                              <table>
                                <thead>       
                              <tr>
                                    <th><input type="text" aria-label="First" class="form-control" value="PERIODE DARI :" required disabled></th>
                                    <th><input id="dari" name="tgl_awal" type="date" value="<?= $tgl_awal; ?>" class="form-control" ></th>
                                    <th><input type="text" aria-label="First" class="form-control" value="SAMPAI  :" required disabled></th>
                                    <th><input id="sampai" name="tgl_akhir" type="date"  value="<?= $tgl_akhir; ?>" class="form-control" ></th>
                                   
                              </tr>  
                              </thead>       
                              </table>
                               <button class="btn btn-primary" style="float: right;" type="submit" id="button-addon3"><i class="fa fa-search"></i> Search</button>
                              <br>
                               <table>
                                <thead>  
                               <tr>
                                    <th><input type="text" aria-label="First" class="form-control" value="SEARCH BY :" required disabled></th>
                                    <th><select class="form-control"  name="searchby" required>
                                                <option value="0" selected disabled>Pilih</option>
                                                  <?php if ( $searchby == 'body_no') echo "
                                                    <option value='body_no' selected>BODY NO</option> 
                                                    <option value='kategori'>KATEGORI</option> 
                                                    <option value='nm_barang'>NAMA BARANG</option>";
                                                  ?>
                                                  <?php if($searchby == 'kategori') echo "
                                                    <option value='kategori' selected>KATEGORI</option>
                                                    <option value='body_no'>BODY NO</option>
                                                    <option value='nm_barang'>NAMA BARANG</option>";
                                                  ?>
                                                   <?php if($searchby == 'nm_barang') echo "
                                                    <option value='nm_barang' selected>NAMA BARANG</option>
                                                    <option value='body_no'>BODY NO</option>
                                                    <option value='kategori'>KATEGORI</option>";
                                                  ?>
                                                  <?php if($searchby == null) echo "<option value='kategori'>KATEGORI</option>
                                                    <option value='body_no'>BODY NO</option>
                                                    <option value='nm_barang'>NAMA BARANG</option>";
                                                  ?>
                                    </select>
                                  </th>
                                  <th><input type="text" aria-label="First" name="keyword" value="<?= $keyword; ?>" class="form-control"></th>
                               </tr>
                              </thead>
                              </table>
                              </form>
                           </div>
                         </div>
                        
                    <!-- /.card-header -->
                      <div class="panel-body">
                        <table  class="table table-striped">
                             <thead>
                            <tr>
                                <th style="width: 10px">No</th>
                                <th>No Surat Keluar</th>
                                <th>Tgl Surat Keluar</th>
                                <th>Note </th>
                                <th>Ke Bagian </th>
                                <th>File </th>
                                <th>Note </th>
                                <th>Status </th>
                             </tr>
                            </thead>
                            <tbody>
                             <?php
                                 $no =0;
                                if($searchby == 'nm_barang') 
                                 {
                                   if ($tgl_akhir==null ||$tgl_awal== null) 
                                   {
                                     $source2 = $this->db->query("select * from view_keluar WHERE nm_barang LIKE'".$keyword."%'");
                                   }
                                   else
                                   {
                                     $source2 = $this->db->query("select * from view_keluar where nm_barang ='".$keyword."' and tgl_transaksi Between'".date('Y-m-d',strtotime($tgl_awal))."'and'".date('Y-m-d',strtotime($tgl_akhir))."'");
                                   }
                                   $source3 = $source2->result_array();
                                   foreach($source3 as $source3){?>
                                   <tr>
                                        <td><?= ++$no; ?></td>
                                        <td><?= $source3['no_srtklr'] ?></td>
                                        <td><?= date('d/m/Y',strtotime($source3['tgl_srtklr'])) ?></td>
                                        <td><?= $source3['note'] ?></td>
                                        <td><?= $source3['nama_bagian'] ?></td>
                                        <td><?= $source3['file'] ?></td>
                                        <td><?= $source3['note_detail'] ?></td>
                                        <td><?php if (empty($source3['percentage']))
                                                    { ?>
                                                      <?= $source3['status'] ?>
                                                    <?php } else { ?>
                                                      <?= $source3['status'] ?> | <?= $source3['percentage'] ?> %
                                                    <?php } ?>
                                        </td>          
                                   <tr> 
                                   <?php }  
                                 }
                                 else
                                 {  
                                  foreach ($datasuratkeluar->result_array() as $rows)            
                                   {?>
                                  <tr>
                                    <?php
                                    
                                      $source2 = $this->db->query("select * from view_keluar where Id_srtklr ='$rows[Id_srtklr]'");
                                    
                                      $total_row = $source2->num_rows();
                                      $source3 = $source2->result_array();
                                    ?>  
                                                          
                                    <td rowspan="<?php echo $total_row ?>"><?= ++$no; ?></td>
                                    <td rowspan="<?php echo $total_row ?>"><?= $rows['no_srtklr'] ?></td>
                                    <td rowspan="<?php echo $total_row ?>"><?= date('d/m/Y',strtotime($rows['tgl_srtklr'])) ?></td>
                                    <td rowspan="<?php echo $total_row ?>"><?= $rows['note'] ?></td>
                                    <td rowspan="<?php echo $total_row ?>"><?= $rows['nama_bagian'] ?></td>

                                   <?php foreach($source3 as $source3){ 
                                     ?>
                                    <td><?= $source3['file'] ?></td>
                                    <td><?= $source3['note_detail'] ?></td>
                                    <td><?php if (empty($source3['percentage']))
                                                    { ?>
                                                      <?= $source3['status'] ?>
                                                    <?php } else { ?>
                                                      <?= $source3['status'] ?> | <?= $source3['percentage'] ?> %
                                                    <?php } ?>
                                        </td>          
                                  </tr>
                                  <?php } ?>
                               <?php } ?>
                             <?php } ?>
                                  <!--  <tr>
                                    <?php if ($total_qty != 0 ) {?>
                                    <td style="text-align: center; background: skyblue" colspan="8">Total</td>
                                    <td style ="background: skyblue"><?= $total_qty; ?></td>
                                    <?php } else {?> 
                                    <?php } ?>
                                  </tr> -->
                                 
                            </tbody>
                        </table>
                         <div style = "float: right ">
                         <?php echo $pagination; ?>
                         </div>
                       
                           <form action="<?=site_url('Laporantransaksi/export_excel')?>" method="post">
                                <input  name="tgl_awal" type="hidden" value="<?= $tgl_awal; ?>" class="form-control">
                                <input  name="tgl_akhir" type="hidden"  value="<?= $tgl_akhir; ?>" class="form-control">
                                <select class="hidden"  name="searchby" required>
                                                <option value="0" selected disabled>Pilih</option>
                                                  <?php if ( $searchby == 'no_body') echo "
                                                    <option value='body_no' selected>NO BODY </option> 
                                                    <option value='kategori'>KATEGORI</option> 
                                                    <option value='nm_barang'>NAMA BARANG</option>";
                                                  ?>
                                                  <?php if($searchby == 'kategori') echo "
                                                    <option value='kategori' selected>KATEGORI</option>
                                                    <option value='body_no'>NO BODY </option>
                                                    <option value='nm_barang'>NAMA BARANG</option>";
                                                  ?>
                                                   <?php if($searchby == 'nm_barang') echo "
                                                    <option value='nm_barang' selected>NAMA BARANG</option>
                                                    <option value='body_no'>NO BODY </option>
                                                    <option value='nm_barang'>NAMA BARANG</option>";
                                                  ?>
                                                  <?php if($searchby == null) echo "<option value='kategori'>KATEGORI</option>
                                                                                   <option value='body_no'>NO BODY </option>
                                                                                   <option value='nm_barang'>NAMA BARANG</option>";
                                                  ?>
                                    </select>
                                <input type="hidden" aria-label="First" name="keyword" value="<?= $keyword; ?>" class="form-control">    
                                <button class="btn btn-success" type="submit" id="button-addon3"><span class="fa fa-file-excel-o"></span> Cetak Excel</button></th>
                          </form>  
                    <!-- /.card-body -->
                </div>
            </div>
        </div>
      </div>
    </div>
        <!-- /.row -->
    </div>


<?php $this->load->view('templates/footer') ?>

</div>
</body>


