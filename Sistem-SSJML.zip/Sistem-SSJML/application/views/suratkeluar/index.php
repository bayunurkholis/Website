<style type="text/css">
    .panel-body{
        overflow: auto;
      }

   #notifications {
    cursor: pointer;
    position: fixed;
    right: 0px;
    z-index: 9999;
    bottom: 0px;
    margin-bottom: 22px;
    margin-right: 15px;
    min-width: 300px; 
    max-width: 800px; 

    }
</style>
<?php $this->load->view('templates/header')?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <!-- Logo -->
    
   <header class="main-header">
      <!-- mini logo for sidebar mini 50x50 pixels -->
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-">
      <!-- Sidebar toggle button-->
      <ul>
 
     <h3 href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">  <?php foreach ($judulweb->result() as $baris) { echo "$baris->nama_pt"; } ?>
        <span class="sr-only">Toggle navigation</span>
      </h3>
     </ul>

    </nav>
    
    <div id="notifications"><?php echo $this->session->flashdata('notifikasi'); ?></div> 
  </header>
<?php $this->load->view('templates/sidebar')?>

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       SURAT KELUAR
      </h1>
    </section>
    <br>
  <div class="container" bgcolor= "#fff">
    <div class="row">
        <div class="col-md-15">
            <div class="panel">
                <div class="panel-heading">
                      <div class="form-group row" >
                        <div class="col-md-5 " style="float: left;">
                         <a href="<?=site_url('Transaksi/create')?>" class="btn btn-primary ">Tambah Surat Keluar</a>
                        </div>
                        <div class="col-md-5 col-md-offset-1" style="float: right;">
                         <form action="<?=site_url('Suratmasuk/index')?>" method="post">     
                               <table>
                                 <thead>  
                                   <tr> 
                                    <th><input type="text" aria-label="First" class="form-control" value="SEARCH BY :" required disabled></th>
                                    <th><select class="form-control"  name="searchby" required>
                                                <option value="0" selected disabled>Pilih</option>
                                                  <?php if ( $searchby == 'no_srtmsk') echo "
                                                    <option value='no_srtmsk' selected>NO SURAT KELUAR</option> 
                                                    <option value='nama_bagian'>NAMA BAGIAN</option> 
                                                    <option value='tgl_srtmsk'>TGL SURAT KELUAR</option>";
                                                  ?>
                                                  <?php if($searchby == 'nama_bagian') echo "
                                                    <option value='nama_bagian' selected>NAMA BAGIAN</option>
                                                    <option value='no_srtmsk'>NO SURAT KELUAR</option>
                                                    <option value='tgl_srtmsk'>TGL SURAT KELUAR</option>";
                                                  ?>
                                                   <?php if($searchby == 'tgl_srtmsk') echo "
                                                    <option value='tgl_srtmsk' selected>TGL SURAT KELUAR</option>
                                                    <option value='no_srtmsk'>NO SURAT KELUAR</option>
                                                    <option value='nama_bagian'>NAMA BAGIAN</option>";
                                                  ?>
                                                  <?php if($searchby == null) echo "<option value='no_srtmsk'>NO SURAT KELUAR</option>
                                                    <option value='nama_bagian'>NAMA BAGIAN</option>
                                                    <option value='tgl_srtmsk'>TGL SURAT KELUAR</option>";
                                                  ?>
                                    </select>
                                  </th>
                                  <th><input type="text" aria-label="First" name="keyword" value="<?= $keyword; ?>" class="form-control"></th>
                                    <th>  <button class="btn btn-primary" style="float: right;" type="submit" id="button-addon3"><i class="fa fa-search"></i> Search</button></th>
                               </tr>
                              </thead>
                             </table>
                            </form>
                            </div>
                           </div>
                    <!-- /.card-header -->
                      <div class="panel-body">
                       <table class="table table-striped">
                            <thead>
                            <tr>
                                <th style="width: 10px">No</th>
                                <th>No. Surat Keluar</th>
                                <th>Tgl Surat</th>
                                <th>Note</th>
                                <th>Ke Bagian</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                             <?php $no=0;
                              foreach ($datasuratkeluar->result_array() as $rows) {?>
                              <tr>
                                <td><?= ++$no; ?></td>
                                <td><?= $rows['no_srtklr'] ?></td>
                                <td><?= date('d/m/Y',strtotime($rows['tgl_srtklr'])) ?></td>
                                <td><?= $rows['note'] ?></td>
                                <td><?= $rows['nama_bagian'] ?></td>
                                <td>
                                 <a class="btn btn-danger text-danger" onclick="return confirm('Are You Sure You Want To Delete ?')" href=" <?=site_url()?>Suratkeluar/delete/<?= $rows['Id_srtklr']; ?>">
                                     <span class="fa fa-trash"></span>
                                  </a>
                                  <a class="btn btn-success text-success" data-toggle="modal" data-target="#view_detailsuratkeluar<?= $rows['Id_srtklr']?>">
                                      <span class="fa fa-eye"></span>
                                  </a>
                                </td>
                              </tr>
                              <?php } ?>
                            </tbody>
                        </table>
                          <div style = "float: right ">
                         <?php echo $pagination; ?>
                         </div>
                    </div>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>
      </div>
    </div>
        <!-- /.row -->
  </div>

<?php $this->load->view('templates/footer') ?>
<?php foreach ($datasuratkeluar->result_array() as $rows)              
            { 
              $rows['Id_srtklr'];
              $rows['no_srtklr'];
              $rows['tgl_srtklr'];
              $rows['note'];
              $rows['nama_bagian'];
 ?>                    
 
<div class="modal fade" id="view_detailsuratkeluar<?= $rows['Id_srtklr']?>">
  
       <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">DETAIL TRANSAKSI</h4>
            </div>
                   <div class="panel-body">
                      <div  class="col-md-12">
                        <div class="col-md-12 col-md-offset-0">
                            <label >NO SURAT KELUAR : </label>  
                            <label type="text" name="no_srtklr"><?= $rows['no_srtklr'] ?></label>
                            <label style="float: right">TGL SURAT KELUAR : 
                            <label type="text" name="tgl_srtklr"><?= date('d/m/Y',strtotime($rows['tgl_srtklr'])); ?></label> 
                        </div>   
                         <div class="col-md-12 col-md-offset-0">
                            <label >NOTE : </label>  
                            <label type="text" name="note"><?= $rows['note'] ?></label>
                            <label style = "float: right">NAMA BAGIAN : 
                            <label type="text" name="nama_bagian"><?= $rows['nama_bagian'] ?></label> 
                        </div>
                       <div class="col-md-10 col-md-offset-0">
                          <br>
                            <p>Berikut daftar lampiran : </p>
                        </div>
                       </div> 
                             <div class="col-md-12">
                               <table border="1" rules="cols" class="table table-striped">
                                 <thead>
                                <tr>
                                    <td style="width: 10px">No</td>
                                    <td style="text-align: center;">File</td>
                                    <td style="text-align: center;">Note</td>
                                    <td style="text-align: center;">Status</td>
                                </tr>
                                </thead>
                                <tbody>
                                 <?php $no=1;
                                 foreach ($dataalldatasuratkeluar->result_array() as $item){ ?>
                                   <tr>
                                    <?php if ($item['Id_srtklr'] == $rows['Id_srtklr']) 
                                    { ?>
                                      <td><?= $no++; ?></td>
                                      <td style="text-align: center;"><?= $item['file'] ?></td> 
                                      <td style="text-align: center;"><?= $item['note_detail'] ?></td>
                                      <td style="text-align: center;">
                                               <?php if (empty($item['percentage']))
                                                { ?>
                                                  <?= $item['status'] ?>
                                                <?php } else { ?>
                                                   <?= $item['status'] ?> | <?= $item['percentage'] ?> %
                                                <?php } ?>           
                                      </td>
                                     <?php } else { }?>          
                                  </tr>
                               <?php } ?>
                           
                                </tbody>

                            </table>
                             
                          </div>
                      
                </div>
         
                  </div>
           <!-- /.modal-content -->
       </div>
    <!-- /.modal-dialog -->
  </div>
  <?php } ?>

  <script> 
    $('#notifications').slideDown('slow').delay(2000).slideUp('fast');  
</script>