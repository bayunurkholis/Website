-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2022 at 05:44 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_sjml`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_bagian`
--

CREATE TABLE `tb_bagian` (
  `id_bagian` int(10) NOT NULL,
  `nama_bagian` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_bagian`
--

INSERT INTO `tb_bagian` (`id_bagian`, `nama_bagian`) VALUES
(1, '1212');

-- --------------------------------------------------------

--
-- Table structure for table `tb_det_surat_keluar`
--

CREATE TABLE `tb_det_surat_keluar` (
  `Id_srtklr` int(30) NOT NULL,
  `file` varchar(60) NOT NULL,
  `note` varchar(150) NOT NULL,
  `status` varchar(80) NOT NULL,
  `percentage` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_det_surat_keluar`
--

INSERT INTO `tb_det_surat_keluar` (`Id_srtklr`, `file`, `note`, `status`, `percentage`) VALUES
(1, 'TES3', '12', '21', '21'),
(1, '2131', '21', '3', '12'),
(2, '121', '3', '12', '121');

-- --------------------------------------------------------

--
-- Table structure for table `tb_det_surat_masuk`
--

CREATE TABLE `tb_det_surat_masuk` (
  `id_srtmsk` int(30) NOT NULL,
  `file` varchar(60) NOT NULL,
  `note` varchar(150) NOT NULL,
  `status` varchar(80) NOT NULL,
  `percentage` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_det_surat_masuk`
--

INSERT INTO `tb_det_surat_masuk` (`id_srtmsk`, `file`, `note`, `status`, `percentage`) VALUES
(1, 'tes', 'tes', 'trs', '80'),
(1, 'oi', 'rede', 'ok', ''),
(2, 'TES3', '12', 'OKE', '');

-- --------------------------------------------------------

--
-- Table structure for table `tb_setting`
--

CREATE TABLE `tb_setting` (
  `id_set` int(10) NOT NULL,
  `nama_pt` varchar(50) NOT NULL,
  `alamat` varchar(150) NOT NULL,
  `no_tlp` varchar(15) NOT NULL,
  `path_img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_setting`
--

INSERT INTO `tb_setting` (`id_set`, `nama_pt`, `alamat`, `no_tlp`, `path_img`) VALUES
(1, 'Sinar Jaya Megah Langeng', 'tegal danas - cikarang', '08123456789', '');

-- --------------------------------------------------------

--
-- Table structure for table `tb_surat_keluar`
--

CREATE TABLE `tb_surat_keluar` (
  `Id_srtklr` int(10) NOT NULL,
  `no_srtklr` varchar(20) NOT NULL,
  `tgl_srtklr` date NOT NULL,
  `note` varchar(150) NOT NULL,
  `id_bagian` int(10) NOT NULL,
  `id_user` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_surat_keluar`
--

INSERT INTO `tb_surat_keluar` (`Id_srtklr`, `no_srtklr`, `tgl_srtklr`, `note`, `id_bagian`, `id_user`) VALUES
(1, '123/invc/2022', '2022-06-01', 'okelah', 1, 1),
(2, '12312', '2022-06-01', '121', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_surat_masuk`
--

CREATE TABLE `tb_surat_masuk` (
  `id_srtmsk` int(10) NOT NULL,
  `no_srtmsk` varchar(20) NOT NULL,
  `tgl_srtmsk` date NOT NULL,
  `note` varchar(150) NOT NULL,
  `id_user` int(10) NOT NULL,
  `id_bagian` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_surat_masuk`
--

INSERT INTO `tb_surat_masuk` (`id_srtmsk`, `no_srtmsk`, `tgl_srtmsk`, `note`, `id_user`, `id_bagian`) VALUES
(1, '1224', '2022-06-01', 'tes', 1, 1),
(2, '123/INV/2022', '2022-06-01', 'TES', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(10) NOT NULL,
  `nama_user` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(80) NOT NULL,
  `hak_user` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `nama_user`, `username`, `password`, `hak_user`) VALUES
(1, 'dede fuji', 'dede fuji', '$2y$10$ervVnwC2OmBwx4DtnJ71KeRDZ77xPSi4cJ5oqs8MX4RmxnuYgCi7u', 'Admin'),
(7, 'bayu nur cholis', 'bayu', '$2y$10$KtjFaqiNFQIVyPyVGksGFu/FbEYQRaluhPXroVOKrqaqH6lGLUFM2', 'Admin');

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_keluar`
-- (See below for the actual view)
--
CREATE TABLE `view_keluar` (
`Id_srtklr` int(10)
,`no_srtklr` varchar(20)
,`tgl_srtklr` date
,`note` varchar(150)
,`nama_bagian` varchar(20)
,`nama_user` varchar(50)
,`file` varchar(60)
,`note_detail` varchar(150)
,`status` varchar(80)
,`percentage` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_masuk`
-- (See below for the actual view)
--
CREATE TABLE `view_masuk` (
`id_srtmsk` int(10)
,`no_srtmsk` varchar(20)
,`tgl_srtmsk` date
,`note` varchar(150)
,`nama_bagian` varchar(20)
,`file` varchar(60)
,`note_detail` varchar(150)
,`status` varchar(80)
,`percentage` varchar(10)
,`nama_user` varchar(50)
);

-- --------------------------------------------------------

--
-- Structure for view `view_keluar`
--
DROP TABLE IF EXISTS `view_keluar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_keluar`  AS  select `tb_surat_keluar`.`Id_srtklr` AS `Id_srtklr`,`tb_surat_keluar`.`no_srtklr` AS `no_srtklr`,`tb_surat_keluar`.`tgl_srtklr` AS `tgl_srtklr`,`tb_surat_keluar`.`note` AS `note`,`tb_bagian`.`nama_bagian` AS `nama_bagian`,`tb_user`.`nama_user` AS `nama_user`,`tb_det_surat_keluar`.`file` AS `file`,`tb_det_surat_keluar`.`note` AS `note_detail`,`tb_det_surat_keluar`.`status` AS `status`,`tb_det_surat_keluar`.`percentage` AS `percentage` from (((`tb_surat_keluar` join `tb_bagian` on((`tb_surat_keluar`.`id_bagian` = `tb_bagian`.`id_bagian`))) join `tb_user` on((`tb_surat_keluar`.`id_user` = `tb_user`.`id_user`))) join `tb_det_surat_keluar` on((`tb_surat_keluar`.`Id_srtklr` = `tb_det_surat_keluar`.`Id_srtklr`))) ;

-- --------------------------------------------------------

--
-- Structure for view `view_masuk`
--
DROP TABLE IF EXISTS `view_masuk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_masuk`  AS  select `tb_surat_masuk`.`id_srtmsk` AS `id_srtmsk`,`tb_surat_masuk`.`no_srtmsk` AS `no_srtmsk`,`tb_surat_masuk`.`tgl_srtmsk` AS `tgl_srtmsk`,`tb_surat_masuk`.`note` AS `note`,`tb_bagian`.`nama_bagian` AS `nama_bagian`,`tb_det_surat_masuk`.`file` AS `file`,`tb_det_surat_masuk`.`note` AS `note_detail`,`tb_det_surat_masuk`.`status` AS `status`,`tb_det_surat_masuk`.`percentage` AS `percentage`,`tb_user`.`nama_user` AS `nama_user` from (((`tb_surat_masuk` join `tb_bagian` on((`tb_surat_masuk`.`id_bagian` = `tb_bagian`.`id_bagian`))) join `tb_user` on((`tb_surat_masuk`.`id_bagian` = `tb_user`.`id_user`))) join `tb_det_surat_masuk` on((`tb_surat_masuk`.`id_srtmsk` = `tb_det_surat_masuk`.`id_srtmsk`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_bagian`
--
ALTER TABLE `tb_bagian`
  ADD PRIMARY KEY (`id_bagian`);

--
-- Indexes for table `tb_setting`
--
ALTER TABLE `tb_setting`
  ADD PRIMARY KEY (`id_set`);

--
-- Indexes for table `tb_surat_keluar`
--
ALTER TABLE `tb_surat_keluar`
  ADD PRIMARY KEY (`Id_srtklr`),
  ADD KEY `id_bagian` (`id_bagian`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `tb_surat_masuk`
--
ALTER TABLE `tb_surat_masuk`
  ADD PRIMARY KEY (`id_srtmsk`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_bagian` (`id_bagian`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_bagian`
--
ALTER TABLE `tb_bagian`
  MODIFY `id_bagian` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_setting`
--
ALTER TABLE `tb_setting`
  MODIFY `id_set` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_surat_keluar`
--
ALTER TABLE `tb_surat_keluar`
  MODIFY `Id_srtklr` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_surat_masuk`
--
ALTER TABLE `tb_surat_masuk`
  MODIFY `id_srtmsk` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_surat_keluar`
--
ALTER TABLE `tb_surat_keluar`
  ADD CONSTRAINT `tb_surat_keluar_ibfk_1` FOREIGN KEY (`id_bagian`) REFERENCES `tb_bagian` (`id_bagian`),
  ADD CONSTRAINT `tb_surat_keluar_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `tb_bagian` (`id_bagian`);

--
-- Constraints for table `tb_surat_masuk`
--
ALTER TABLE `tb_surat_masuk`
  ADD CONSTRAINT `tb_surat_masuk_ibfk_1` FOREIGN KEY (`id_bagian`) REFERENCES `tb_bagian` (`id_bagian`),
  ADD CONSTRAINT `tb_surat_masuk_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `tb_user` (`id_user`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
